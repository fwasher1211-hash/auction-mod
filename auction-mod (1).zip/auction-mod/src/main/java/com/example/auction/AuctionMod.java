package com.example.auction;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class AuctionMod implements ModInitializer {
    private final AuctionManager manager = new AuctionManager();

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(manager::tick);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> manager.onJoin(handler.player));
        ServerLifecycleEvents.SERVER_STOPPING.register(manager::cancelOnStop);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) ->
            dispatcher.register(CommandManager.literal("auction")
                // /auction start <minutes> <startingBid>   (auctions the item in your main hand)
                .then(CommandManager.literal("start")
                    .then(CommandManager.argument("minutes", IntegerArgumentType.integer(1, 1440))
                        .then(CommandManager.argument("startingBid", IntegerArgumentType.integer(1, 100000))
                            .executes(ctx -> {
                                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                String err = manager.start(ctx.getSource().getServer(), p,
                                    IntegerArgumentType.getInteger(ctx, "minutes"),
                                    IntegerArgumentType.getInteger(ctx, "startingBid"));
                                return reply(ctx.getSource(), err);
                            }))))
                // /auction bid <amount>
                .then(CommandManager.literal("bid")
                    .then(CommandManager.argument("amount", IntegerArgumentType.integer(1, 100000))
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            String err = manager.bid(ctx.getSource().getServer(), p,
                                IntegerArgumentType.getInteger(ctx, "amount"));
                            return reply(ctx.getSource(), err);
                        })))
                // /auction info
                .then(CommandManager.literal("info").executes(ctx -> {
                    ctx.getSource().sendFeedback(() -> manager.info(), false);
                    return 1;
                }))
                // /auction cancel  (seller or op)
                .then(CommandManager.literal("cancel").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    String err = manager.cancel(ctx.getSource().getServer(), p,
                        ctx.getSource().hasPermissionLevel(2));
                    return reply(ctx.getSource(), err);
                }))
            ));
    }

    private static int reply(ServerCommandSource src, String err) {
        if (err != null) {
            src.sendError(Text.literal(err));
            return 0;
        }
        return 1;
    }
}
