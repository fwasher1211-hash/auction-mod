# Auction Mod (Fabric, Minecraft 1.21.1) — server-side, players don't need it installed

Commands:
  /auction start <minutes> <startingBid>  - auctions the item in your main hand
  /auction bid <amount>                   - bid in diamonds (taken from inventory, refunded if outbid)
  /auction info                           - show current highest bid & time left
  /auction cancel                         - seller or op cancels, everything returned

A boss bar at the top of everyone's screen shows the item, highest bid, bidder and countdown.
Change the currency in AuctionManager.CURRENCY.

Build: install JDK 21, then run `gradle build` (or copy src/ into the official Fabric example mod template
and run `./gradlew build`). The jar appears in build/libs/. Put it + Fabric API in your server's mods folder.

## Get the jar without installing anything
1. Create a free GitHub repo and upload everything in this folder (keep the .github folder).
2. Open the repo's Actions tab, wait ~3 minutes for "Build jar" to finish.
3. Click the run, download the "auctionmod-jar" artifact, and unzip it. Use auctionmod-1.0.0.jar (not the -sources one).
4. Put that jar plus Fabric API (1.21.1) in your server's mods folder.
